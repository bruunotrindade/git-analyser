import os
import subprocess
import threading


def runCollect(path):
    os.system("java -jar JAR/TMCollect.jar " + str(path))


def runAnalysis(path):
    os.system("java -jar JAR/TMAnalysis.jar " + str(path))

def runACCollect(path):
    os.system("java -jar JAR/TMACCollect.jar " + str(path))

def download(url):
    os.system("git clone " + str(url))

def main():
    f = open("Reps/download.sh", "r")

#    for line in f:
 #       url = line.split(" ")[2]
  #      threading.Thread(target=download, args=(url, )).start()

    #paths = ["/media/dados/brunotrindade/Reps/moby", "/media/dados/brunotrindade/Reps/tensorflow", "/media/dados/brunotrindade/Reps/three.js", "/media/dados/brunotrindade/Reps/TypeScript"]
    #paths = ["/media/dados/brunotrindade/Reps/tensorflow"]    
    paths  = ["/media/dados/brunotrindade/Reps/atom", "/media/dados/brunotrindade/Reps/bitcoin/", "/media/dados/brunotrindade/Reps/bootstrap/", "/media/dados/brunotrindade/Reps/Chart.js/", "/media/dados/brunotrindade/Reps/d3/", "/media/dados/brunotrindade/Reps/django/", "/media/dados/brunotrindade/Reps/elasticsearch/", "/media/dados/brunotrindade/Reps/electron/", "/media/dados/brunotrindade/Reps/express/", "/media/dados/brunotrindade/Reps/flask/", "/media/dados/brunotrindade/Reps/flutter/", "/media/dados/brunotrindade/Reps/Font-Awesome/", "/media/dados/brunotrindade/Reps/go/", "/media/dados/brunotrindade/Reps/lantern/", "/media/dados/brunotrindade/Reps/laravel/", "/media/dados/brunotrindade/Reps/lodash/", "/media/dados/brunotrindade/Reps/meteor/", "/media/dados/brunotrindade/Reps/moby/", "/media/dados/brunotrindade/Reps/moment/", "/media/dados/brunotrindade/Reps/node/", "/media/dados/brunotrindade/Reps/oh-my-zsh/", "/media/dados/brunotrindade/Reps/rails/", "/media/dados/brunotrindade/Reps/react/", "/media/dados/brunotrindade/Reps/react-native/", "/media/dados/brunotrindade/Reps/redux/", "/media/dados/brunotrindade/Reps/reveal.js/", "/media/dados/brunotrindade/Reps/RxJava/", "/media/dados/brunotrindade/Reps/socket.io/", "/media/dados/brunotrindade/Reps/swift/", "/media/dados/brunotrindade/Reps/tensorflow/", "/media/dados/brunotrindade/Reps/three.js/", "/media/dados/brunotrindade/Reps/TypeScript/", "/media/dados/brunotrindade/Reps/vscode/", "/media/dados/brunotrindade/Reps/vue/"]
    #paths = ["/media/dados/brunotrindade/Reps/lantern", "/media/dados/brunotrindade/Reps/moby", "/media/dados/brunotrindade/Reps/node", "/media/dados/brunotrindade/Reps/rails", "/media/dados/brunotrindade/RxJava", "/media/dados/brunotrindade/Reps/three.js", "/media/dados/brunotrindade/Reps/TypeScript", "/media/dados/brunotrindade/Reps/vscode"]
    for path in paths:
        threading.Thread(target=runACCollect, args=(path, )).start()
    
    #str = ""
    #for path in paths:
    #    str += path + " "
    #runACCollect(str)
    print("Encerrou")
main()
