import os
import subprocess
import threading


def run(path):
    os.system("java -jar TM.jar " + str(path))


def main():
    #paths  = ["/media/dados/brunotrindade/Reps/atom/", "/media/dados/brunotrindade/Reps/awesome-python/"]
    paths = ["/media/dados/brunotrindade/Reps/reveal.js", "/media/dados/brunotrindade/Reps/redux"]
    for path in paths:
        threading.Thread(target=run, args=(path, )).start()

    print("Encerrou")


main()
