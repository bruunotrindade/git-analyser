from datetime import datetime
import os

while True:
	now = datetime.now()

	if int(now.strftime("%H")) == 14:
		print("Iniciando analise")
		os.system("nohup python3 /media/dados/brunotrindade/main2.py > outputConflito &")
		break
		
